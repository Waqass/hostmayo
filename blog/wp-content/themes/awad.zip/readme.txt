=== Awad ===

Awad, Copyright (C) 2016 Waqass Khalid
Awad is distributed under the terms of the GNU GPL
Awad is based on Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc.
Underscores is distributed under the terms of the GNU GPL v2 or later.

Requires at least: 4.0
Tested up to: 4.6.1
Stable tag: 1.2.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Awad is a fast clean theme built upon underscores.


= Does this theme support any plugins? =

Araiz includes support for Infinite Scroll in Jetpack.

== Installation ==
	
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Credits ==

* Based on Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2015 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)

== Changelog ==

= 1.0 - October 12 2016 =
* Initial release
