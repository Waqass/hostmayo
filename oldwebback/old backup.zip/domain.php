<div class="domain">
	<div class="container">
		<h2>Your Perfect Domain is Here !!</h2>
		<div class="search-box">
              <form action="domain.html">
                  <div class="domain-search-box">
                     <input type="hidden" name="showrelated" value="true">
                        <input type="text" maxlength="30"  class="domains-input optionalField" onfocus="this.value = '';" value="Find your perfect domain name today." />
                        <div class="domains-select"> <span id="tldDisplay" class="tlds">.com</span> <span class="tlds-dd"> </span>
                          <div class="ie-fix">
                            <select class="brd-fix" id="tldlist">
                             <option value="com">.com</option>
                              <option value="net">.net</option>
                              <option value="in">.in</option>
                              <option value="org">.org</option>
                              <option value="info">.info</option>
                              <option value="biz">.biz</option>
                              <option value="us">.us</option>
                              <option value="eu">.eu</option>
                              <option value="co.uk">.co.uk</option>
                              <option value="mobi">.mobi</option>
                              <option value="asia">.asia</option>
                              <option value="name">.name</option>
                              <option value="tel">.tel</option>
                              <option value="co.in">.co.in</option>
                              <option value="tv">.tv</option>
                              <option value="me">.me</option>
                              <option value="ws">.ws</option>
                              <option value="bz">.bz</option>
                              <option value="cc">.cc</option>
                              <option value="org.uk">.org.uk</option>
                              <option value="me.uk">.me.uk</option>
                              <option value="net.in">.net.in</option>
                              <option value="org.in">.org.in</option>
                              <option value="ind.in">.ind.in</option>
                              <option value="firm.in">.firm.in</option>
                              <option value="gen.in">.gen.in</option>
                              <option value="mn">.mn</option>
                              <option value="us.com">.us.com</option>
                              <option value="eu.com">.eu.com</option>
                              <option value="uk.com">.uk.com</option>
                              <option value="uk.net">.uk.net</option>
                              <option value="gb.com">.gb.com</option>
                              <option value="gb.net">.gb.net</option>
                              <option value="de.com">.de.com</option>
                              <option value="cn.com">.cn.com</option>
                              <option value="qc.com">.qc.com</option>
                              <option value="kr.com">.kr.com</option>
                              <option value="ae.org">.ae.org</option>
                              <option value="br.com">.br.com</option>
                              <option value="hu.com">.hu.com</option>
                              <option value="jpn.com">.jpn.com</option>
                              <option value="no.com">.no.com</option>
                              <option value="ru.com">.ru.com</option>
                              <option value="sa.com">.sa.com</option>
                              <option value="se.com">.se.com</option>
                              <option value="se.net">.se.net</option>
                              <option value="uy.com">.uy.com</option>
                              <option value="za.com">.za.com</option>
                              <option value="cn">.cn</option>
                              <option value="com.cn">.com.cn</option>
                              <option value="net.cn">.net.cn</option>
                              <option value="org.cn">.org.cn</option>
                              <option value="co">.co</option>
                              <option value="gr.com">.gr.com</option>
                              <option value="co.nz">.co.nz</option>
                              <option value="net.nz">.net.nz</option>
                              <option value="org.nz">.org.nz</option>
                              <option value="com.co">.com.co</option>
                              <option value="net.co">.net.co</option>
                              <option value="nom.co">.nom.co</option>
                              <option value="ca">.ca</option>
                              <option value="de">.de</option>
                              <option value="es">.es</option>
                              <option value="com.au">.com.au</option>
                              <option value="net.au">.net.au</option>
                              <option value="xxx">.xxx</option>
                              <option value="ru">.ru</option>
                              <option value="com.ru">.com.ru</option>
                              <option value="net.ru">.net.ru</option>
                              <option value="org.ru">.org.ru</option>
                              <option value="pro">.pro</option>
                              <option value="sx">.sx</option>
                              <option value="nl">.nl</option>
                              <option value="pw">.pw</option>
                            </select>
                          </div>
                        </div>
                        <input type="submit" value="" class="domain-submit" onclick="" />
                    </div>      
                 </form>
                 </div>
                       <script type="text/javascript">
                       $('#tldlist').change(function(event) {
                            $('#tldDisplay').html( '.' +$('#tldlist').val());
                        }); 
                    </script>      
	    </div>
</div>  