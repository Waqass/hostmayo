<footer class="footer-distributed">
			<div class="footer-left">
				<ul class="footer-links">
                                    <li><p><a href="./privacy.php"> Privacy Policy</a></p></li>
                                    <li><p><a href="./refund.php"> Refund Policy</a></p></li>
                                    <li><p><a href="./aboutus.php">About Us</a></p></li>
                                    <li><p><a href="./contactus.php">Contact Us</a></p></li>
                                </ul>
			</div>

			<div class="footer-center hidden-xs">

				<div>
					<i class="fa fa-map-marker"></i>
					<p><span>Walton</span> LHR, PK</p>
				</div>

				<div>
					<i class="fa fa-envelope"></i>
                                            <a href="contactus.php"><p>Contact Us</p></a>
				</div>

				<div>
					<i class="fa fa-envelope"></i>
					<p><a href="mailto:support@company.com">admin@hostmayo.com</a></p>
				</div>

			</div>

			<div class="footer-right">

				<p class="footer-company-about">
					<span>About the company</span>
					Host Mayo is one of the few companies providing ultra fast web hosting at very affordable rates. The company is working under the umbrella of Mayo.   
				</p>

				<div class="footer-icons">

					<a href="https://www.facebook.com/hostmayoservers"><i class="fa fa-facebook"></i></a>
					<a href="https://plus.google.com/b/111671310264833997946/111671310264833997946/about/p/pub?hl=en-GB&service=plus"><i class="fa fa-google-plus-square"></i></a>
					<a href="https://www.linkedin.com/company/10151122?trk=tyah&trkInfo=clickedVertical%3Acompany%2CclickedEntityId%3A10151122%2Cidx%3A1-1-1%2CtarId%3A1440938663402%2Ctas%3Ahost%20mayo"><i class="fa fa-linkedin"></i></a>
					

				</div>

			</div>

</footer>
<div class="footer">
        <div class="col-sm-12">
            <div class="bottom">
            Accepted Modes of Payment:
            <img class="co" src="images/2co.png">
            <i class="fa fa-cc-visa"></i>
            <i class="fa fa-cc-mastercard"></i>
            <i class="fa fa-cc-paypal"></i>
            
            
            </div>
        </div>
	<div class="container">
            <div class="col-sm-4">
               <p></p>
           </div>
            <div class="col-sm-4">
                 <p>Copyright © 2015<a href="http://hostmayo.com/"> Hostmayo.com</a></p>
           </div>
            <div class="col-sm-4">
                <p></p>
           </div>
        </div>
</div>
</body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js" integrity="sha256-Sk3nkD6mLTMOF0EOpNtsIry+s1CsaqQC1rVLTAy+0yc= sha512-K1qjQ+NcF2TYO/eI3M6v8EiNYZfA95pQumfvcVrTHtwQVDG+aHRqLi/ETn2uB+1JqwYqVG3LIvdm9lj6imS/pQ==" crossorigin="anonymous"></script> 
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
<script src="js/jquery.easydropdown.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $.goup();
});
</script>
<script>
        $(document).ready(function() {
                $('.popup-with-zoom-anim').magnificPopup({
                        type: 'inline',
                        fixedContentPos: false,
                        fixedBgPos: true,
                        overflowY: 'auto',
                        closeBtnInside: true,
                        preloader: false,
                        midClick: true,
                        removalDelay: 300,
                        mainClass: 'my-mfp-zoom-in'
        });
});
</script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-34351594-2', 'auto');
  ga('send', 'pageview');

</script>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var $_Tawk_API={},$_Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5574520ce93587bc57f6d215/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->